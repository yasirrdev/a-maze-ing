"""mazegen: reusable maze generation library.

Example::
    from mazegen.core import MazeGenerator

    gen = MazeGenerator(width=20, height=15, seed=42)
    gen.generate()

    print(gen.solution)      # ['S', 'E', 'E', ...]
    print(gen.maze[0][0])    # valor hex de la celda (0,0)
"""
from maze.model import Maze
from maze.generator import create_generator, embed_pattern_42
from maze.solver import solve_bfs


class MazeGenerator:
    def __init__(self, width=20, height=15, entry=(0, 0),
                 exit_=None, algorithm="dfs", seed=None, perfect=True):
        self.width = width
        self.height = height
        self.entry = entry
        self.exit_ = exit_ or (width - 1, height - 1)
        self.algorithm = algorithm
        self.seed = seed
        self.perfect = perfect
        self._maze = None

    def generate(self) -> "MazeGenerator":
        maze = Maze(self.width, self.height, self.entry, self.exit_)
        embed_pattern_42(maze)
        gen = create_generator(self.algorithm, self.seed)
        gen.generate(maze)
        maze.open_border_for_entry_exit()
        maze.solution = solve_bfs(maze) or []
        self._maze = maze
        return self

    @property
    def solution(self) -> list:
        return list(self._maze.solution) if self._maze else []

    @property
    def maze(self) -> list:
        """Grid como lista 2D de hex chars."""
        if not self._maze:
            return []
        return [[self._maze.cells[y][x].hex_char()
                 for x in range(self.width)]
                for y in range(self.height)]
